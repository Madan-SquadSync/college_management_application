import 'package:nricse123/bussiness/entites/student.dart';

List<Student> listOfStudents = [];
