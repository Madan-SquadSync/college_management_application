

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

FirebaseAuth firebaseAuth = FirebaseAuth.instance;

final database = FirebaseDatabase.instance
    .refFromURL("https://loginmadan2-default-rtdb.firebaseio.com/");




    
