import 'package:nricse123/bussiness/entites/period_detail_entity.dart';

List<PeriodDetailEntity> listOfPeriodDetailEntity = [];
