import 'package:nricse123/bussiness/entites/faculty_data_entity.dart';

List<FacultyEntity> listOfFacultyEtity = [];
