List<String> selectedSubjects = [];
