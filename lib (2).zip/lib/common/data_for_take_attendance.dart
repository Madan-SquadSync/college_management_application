import 'package:nricse123/bussiness/entites/student.dart';

String seletedBatch = '';
String seletedSection = '';
String seletedSubject = '';

List<String> listOfPeriods = [
  "Period 1",
  "Period 2",
  "Period 3",
  "period 4",
  "period 5",
  "Period 6",
  "Period 7",
  "Period 8"
];

List<String> selectedPeriods = [];

List<Student> listOfAbsentStudents = [];

List<String> listOfBatch = [];
List<String> listOfSections = [];
List<String> listOfSubjects = [];
