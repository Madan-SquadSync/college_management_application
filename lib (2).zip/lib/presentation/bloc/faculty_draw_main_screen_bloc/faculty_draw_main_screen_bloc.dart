import 'dart:async';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nricse123/common/attendance_student_list.dart';
import 'package:nricse123/common/data.dart';
import 'package:nricse123/common/data_for_take_attendance.dart';
import 'package:nricse123/data/data_source/retrieve_batch_data.dart';
import 'package:nricse123/data/data_source/retrieve_section_data.dart';
import 'package:nricse123/data/data_source/retrive_faculty_subjects.dart';
import 'package:nricse123/presentation/bloc/faculty_draw_main_screen_bloc/faculty_draw_main_screen_event.dart';
import 'package:nricse123/presentation/bloc/faculty_draw_main_screen_bloc/faculty_draw_main_screen_state.dart';

class FacultyDrawMainScreenBloc
    extends Bloc<FacultyDrawMainScreenEvent, FacultyDrawMainScreenState> {
  FacultyDrawMainScreenBloc()
      : super(FacultyDrawMainScreenInitializationState(currentScreen: 3)) {
    on<FacultyDrawMainScreenInitialEvent>(facultyDrawMainScreenInitialEvent);

    on<FacultyDrawMainScreenUpdateEvent>(facultyDrawMainScreenUpdateEvent);
  }

  FutureOr<void> facultyDrawMainScreenInitialEvent(
      FacultyDrawMainScreenInitialEvent event,
      Emitter<FacultyDrawMainScreenState> emit) {}

  FutureOr<void> facultyDrawMainScreenUpdateEvent(
      FacultyDrawMainScreenUpdateEvent event,
      Emitter<FacultyDrawMainScreenState> emit) async{
        
    listOfStudents = [];
    seletedBatch = "";
    seletedSection = "";
      if(listOfBatch.isEmpty && listOfSections.isEmpty){
        listOfBatch = await RetrieveBatchData().retrieveBatch(event.context);
      listOfSections =
          await RetrieveSectionData().retrieveSection(event.context);
          listOfSubjects=await RetrieveFacultySubjects().getSubjectsForFaculty(firebaseAuth.currentUser!.email!, event.context);
      }
    emit(FacultyDrawMainScreenUpdateState(changeCurrentScreen: event.value));
  }
}
