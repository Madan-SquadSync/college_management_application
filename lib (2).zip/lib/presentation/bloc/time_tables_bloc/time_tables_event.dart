abstract class TimeTablesEvent {}

class TimeTableChangeNumberEvent extends TimeTablesEvent {}
