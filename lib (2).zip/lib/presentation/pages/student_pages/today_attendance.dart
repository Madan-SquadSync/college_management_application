import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nricse123/common/data_for_today_attendance.dart';
import 'package:nricse123/presentation/bloc/today_attendance_bloc/today_attendance_bloc.dart';
import 'package:nricse123/presentation/bloc/today_attendance_bloc/today_attendance_event.dart';
import 'package:nricse123/presentation/bloc/today_attendance_bloc/today_attendance_state.dart';

class TodayAttendance extends StatelessWidget {
  const TodayAttendance({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    BlocProvider.of<TodayAttendanceBloc>(context).add(
        TodayAttendanceInitialEvent(
            context: context, date: "29-3-2024 ", rollNumber: '22KP1A0521'));
    return Scaffold(
      appBar: AppBar(
        title: const Text("Today Attendance"),
      ),
      body: BlocConsumer<TodayAttendanceBloc, TodayAttendanceState>(
        bloc: context.read<TodayAttendanceBloc>(),
        listener: (context, state) {},
        builder: (context, state) {
          return ListView(
            children: [
              ...listOfPeriodDetailEntity.map((e) => Container(
                    height: 50,
                    decoration: ShapeDecoration(
                      color: e.attendance ? Colors.lightBlue : Colors.red,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    child: Center(
                      child: Text(e.period),
                    ),
                  ))
            ],
          );
        },
      ),
    );
  }
}
