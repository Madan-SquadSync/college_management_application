 class StudentResultEntity {
  final String name;
  final Map semstersResult;

  StudentResultEntity({required this.name, required this.semstersResult});
}
