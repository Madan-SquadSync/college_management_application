import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nricse123/bussiness/usecase/retrieve_student_daily_attendance_repository.dart';
import 'package:nricse123/common/data.dart';
import 'package:nricse123/data/repository/student_today_attendance_data_repository.dart';
import 'package:nricse123/presentation/bloc/today_attendance_bloc/today_attendance_bloc.dart';
import 'package:nricse123/presentation/pages/login_screens_of_teacher_student_parent.dart';
import 'package:nricse123/presentation/pages/student_pages/today_attendance.dart';
import 'package:nricse123/presentation/widgets/Navigating_one_place_to_another_place.dart';
import 'package:nricse123/presentation/widgets/functions_for_sheets_snackbar_banners.dart';
import 'package:shared_preferences/shared_preferences.dart';

class StudentDrawMainScreen extends StatelessWidget {
  const StudentDrawMainScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text("Student"),
          actions: [
            TextButton(
                onPressed: () async {
                  await firebaseAuth.signOut();
                  SharedPreferences prefs =
                      await SharedPreferences.getInstance();
                  await prefs.setBool('isStudent', false);
                  // ignore: use_build_context_synchronously
                  showSnackbarScreen(context, "Sign Out Successfully");
                  // ignore: use_build_context_synchronously
                  NavigatingOnePlaceToAnotherPlace().navigatePageDeletePervious(
                      context, const LoginScreensOfTeacherStudentParent());
                },
                child: const Text("Log out"))
          ],
        ),
        body: ListView(
          children: [
            ElevatedButton.icon(
                onPressed: () {
                  NavigatingOnePlaceToAnotherPlace().navigatePage(
                      context,
                      BlocProvider(
                        create: (context) => TodayAttendanceBloc(
                            retrieveStudentDailyAttendanceRepository:
                                RetrieveStudentDailyAttendanceRepository(
                                    todayAttendanceBusinessRepository:
                                        StudentTodayAttendanceDataRepository())),
                        child: const TodayAttendance(),
                      ));
                },
                icon: const Icon(Icons.co_present_sharp),
                label: const Text("Today Attendance"))
          ],
        ));
  }
}
