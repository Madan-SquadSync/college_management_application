class StudentResultModel {
  final String name;
  final Map semstersResult;

  StudentResultModel({required this.name, required this.semstersResult});
}
